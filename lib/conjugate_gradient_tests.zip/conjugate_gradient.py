# -*- coding: utf-8 -*-
"""
Created on Thu Aug 26 06:28:19 2021

@author: osman
"""

import numpy as np
import QR

class ConjugateGradient:
    def __init__(self, A):
        if A.shape[0] != A.shape[1]:
            print("A is not a square matrix!")
        self.n = A.shape[0]
        self.A = A.copy()
        self.machine_tol = 1.0e-17;
        
    
    # here x is np.array with dimension n
    def multiply_A(self,x):
        return np.matmul(self.A,x)
    
    #create_approximate_eigenmodes (old name)
    def create_ritz_vectors(self, b, num_vectors, sorting=True):
        W, diagonal, sub_diagonal = self.lanczos_iteration(b, num_vectors, 1.0e-10)
        if(num_vectors != len(diagonal)):
            print("Careful. Lanczos Iteration converged too early, num_vectors = "+str(num_vectors)+" > "+str(len(diagonal)))
            num_vectors = len(diagonal)
        tri_diag = np.zeros([num_vectors,num_vectors])
        for i in range(1,num_vectors-1):
            tri_diag[i,i] = diagonal[i]
            tri_diag[i,i+1] = sub_diagonal[i]
            tri_diag[i,i-1]= sub_diagonal[i-1]
        tri_diag[0,0]=diagonal[0]
        tri_diag[0,1]=sub_diagonal[0]
        tri_diag[num_vectors-1,num_vectors-1]=diagonal[num_vectors-1]
        tri_diag[num_vectors-1,num_vectors-2]=sub_diagonal[num_vectors-2]
        eigvals,Q0 = np.linalg.eig(tri_diag)
        Q1 = np.matmul(W.transpose(),Q0).transpose()
        if sorting:
            Q = np.zeros([num_vectors,self.n])
            sorted_eig_vals = sorted(range(num_vectors), key=lambda k: -eigvals[k])
            for i in range(num_vectors):
                Q[i]=Q1[sorted_eig_vals[i]].copy()
            return Q
        else:
            return Q1
        
    #create_approximate_eigenmodes (old name)
    def create_ritz_vectors_with_jacobi(self, b, num_vectors, sorting=True, jacobi_threshold=01e-10, jacobi_max_it=300, verbose = False):
        W, diagonal, sub_diagonal = self.lanczos_iteration(b, num_vectors, 1.0e-10)
        if(num_vectors != len(diagonal)):
            print("Careful. Lanczos Iteration converged too early, num_vectors = "+str(num_vectors)+" > "+str(len(diagonal)))
            num_vectors = len(diagonal)
        tri_diag = np.zeros([num_vectors,num_vectors])
        for i in range(1,num_vectors-1):
            tri_diag[i,i] = diagonal[i]
            tri_diag[i,i+1] = sub_diagonal[i]
            tri_diag[i,i-1]= sub_diagonal[i-1]
        tri_diag[0,0]=diagonal[0]
        tri_diag[0,1]=sub_diagonal[0]
        tri_diag[num_vectors-1,num_vectors-1]=diagonal[num_vectors-1]
        tri_diag[num_vectors-1,num_vectors-2]=sub_diagonal[num_vectors-2]
        R = self.jacobi_diagonalization(tri_diag,jacobi_threshold, jacobi_max_it, verbose)
        Q1 = np.matmul(W.transpose(),R).transpose()
        if sorting:
            D = np.matmul(R.transpose(),np.matmul(tri_diag,R))
            Q = np.zeros([num_vectors,self.n])
            sorted_eig_vals = sorted(range(num_vectors), key=lambda k: -D[k,k])
            for i in range(num_vectors):
                Q[i]=Q1[sorted_eig_vals[i]].copy()
            return Q
        else:
            return Q1
    
    
    #precond is num_vectors x self.n np array
    #Old name: create_lambda_vals

    def create_ritz_values(self,precond,relative=True):
        lambda_ = np.zeros(precond.shape[0])
        for i in range(precond.shape[0]):
            dotx = np.dot(precond[i],precond[i])
            if dotx < self.machine_tol:
                print("Error! Zero vector in Preconditioner.")
                return
            lambda_[i] = np.dot(precond[i],np.matmul(self.A,precond[i]))
            if relative:
                lambda_[i] = lambda_[i]/dotx
        return lambda_
        
    def project_noisy_ritz_vectors_on_lanczos_space(self,b,Q_noisy, normalize=True):
        num_vectors = len(Q_noisy)
        lanczos_vectors, diagonal_, sub_diagonal_ = self.lanczos_iteration(b, num_vectors)
        projection_coef = np.matmul(Q_noisy,lanczos_vectors.transpose()).transpose()
        Q_noisy_projected_on_lanczos = np.matmul(lanczos_vectors.transpose(),projection_coef).transpose()
        if(normalize):
            for i in range(num_vectors):
                Q_noisy_projected_on_lanczos[i]=Q_noisy_projected_on_lanczos[i]/np.linalg.norm(Q_noisy_projected_on_lanczos[i])
        return Q_noisy_projected_on_lanczos

    #Q is num_vectors x self.n np array
    #Rename the method
    #Old name: mult_precond_approximate_eigenmodes
    def mult_precond_method1(self,x,Q,lambda_):
        y = np.copy(x)
        for i in range(Q.shape[0]):
            qTx = np.dot(Q[i],x)
            y = y + qTx*(1/lambda_[i] - 1.0)*Q[i]
        return y

    


    def refine_matrix(self, Q_noisy,orthogonalize = True, diagonalize = True):
        #Q_noisy^T*Q_noisy ~= Id
        #Q_noisy^T*A*Q_noisy is not tridiagonal
        #This method fixes that
        
        if(orthogonalize):
            [Q_noisy, R]=np.linalg.qr(Q_noisy.transpose(), mode="reduced")
            Q_noisy = Q_noisy.transpose()
        if(diagonalize):
            A_tilde = np.matmul(Q_noisy,np.matmul(self.A, Q_noisy.transpose()))
            eigvals,Q0 = np.linalg.eig(A_tilde)
            Q_noisy = np.matmul(Q_noisy.transpose(),Q0).transpose()
        
    #Q is num_vectors x self.n np array
    #Rename the method
    #Old name: mult_precond_approximate_eigenmodes
    def mult_precond_2_helper(self,x,Q,lambda_):
        y = np.zeros(x.shape)
        for i in range(Q.shape[0]):
            qTx = np.dot(Q[i],x)
            y = y + qTx*(1/lambda_[i])*Q[i]
        return y
    
    #this is incomplete, and shit.
    def mult_precond_2(self, x, mult_precond, mult_low_rank_precond):
        #multiply HPH^T
        #Assuming A=A^T
        
        y = x.copy()
        y2 = mult_low_rank_precond(x)
        y = y - self.multiply_A(y2)
        y = mult_precond(y)
        y2 = self.multiply_A(y)
        return y - mult_low_rank_precond(y2)

    def mult_diag_precond(self,x):
        y = np.zeros(x.shape)
        for i in range(self.n):
            if self.A[i,i]>self.machine_tol:
                y[i] = x[i]/self.A[i,i]
        return y
    
    #update this one
    def pcg_normal(self, x_init, b, mult_precond, max_it=100, tol=1.0e-12,verbose=True):
        #b is rhs
        #x_init is initial prediction
        #mult_precond is a function for multiplying preconditioner
        res_arr = []
        x = x_init.copy()
        ax = np.matmul(self.A, x_init)
        res = np.linalg.norm(ax-b)
        res_arr = res_arr + [res]
        if verbose:
            print("First PCG residual = "+str(res))
        if res<tol:
            if verbose:
                print("PCG converged in 0 iteration. Final residual is "+str(res))
            return [x, res_arr]
        
        r = b.copy()
        r = r - ax
        z = mult_precond(r)        
        p = z.copy()
        rz = np.dot(r,z)
        rz_k = rz;
        for it in range(max_it):
            ax = np.matmul(self.A, p)
            alpha = rz_k/np.dot(p,ax)
            x = x + p*alpha
            r = r - ax*alpha
            z = mult_precond(r)        
            rz = np.dot(r,z)
            res = np.linalg.norm(np.matmul(self.A, x)-b)
            res_arr = res_arr + [res]
            if res < tol:
                if verbose:
                    print("PCG residual = "+str(res))
                    print("PCG converged in "+str(it)+ " iterations.")
                return [x, res_arr]
            if it != max_it - 1: 
                beta  rz/rz_k
                pk_1 = p.copy()
                p = z.copy()
                p = p + pk_1*beta
                rz_k = rz
        
        if verbose:
            print("PCG residual = "+str(res))
            print("PCG converged in "+str(max_it)+ " iterations.")
            
        return [x, res_arr]
     
    def jacobi_diagonalization(self, A_tilde, threshold = 1e-5, max_it = 100, verbose = False):
        #Jacobi Iteration
        R = np.identity(A_tilde.shape[0])
        #qri =1e-5
        B = A_tilde.copy()
        non_diag_max = QR.max_non_diag_abs_val(B)
        n_step = 0
        while non_diag_max >= threshold and n_step < max_it: 
            n_step += 1
            max_index=QR.search_max_index(B)
            p = max_index[0]
            q = max_index[1]
            B,phi = QR.elim_diag(B,p,q)
            R = QR.make_ortho_mat(A_tilde,R,p,q,phi)
            non_diag_max= QR.max_non_diag_abs_val(B)
            #print ("n_step=",n_step,", non_diag_max=",non_diag_max )
        
        if verbose:
            if n_step == max_it:
                print("Jacobi diagonalization converged in max_it = " +str(max_it)+" iterations. Max_off_diagonal entry = "+str(non_diag_max))
            else: 
                print("Jacobi diagonalization converged in " +str(n_step)+" iterations. Max_off_diagonal entry < "+str(threshold))
        return R
        
    def pcg_normal_old(self, x_init, b, mult_precond, max_it=100, tol=1.0e-12,verbose=True):
        #b is rhs
        #x_init is initial prediction
        #mult_precond is a function for multiplying preconditioner
        res_arr = []
        x = x_init.copy()
        ax = np.matmul(self.A, x_init)
        res = np.linalg.norm(ax-b)
        res_arr = res_arr + [res]
        if verbose:
            print("First PCG residual = "+str(res))
        if res<tol:
            if verbose:
                print("PCG converged in 0 iteration. Final residual is "+str(res))
            return [x, res_arr]
        
        r = b.copy()
        r = r - ax
        #lambda_ = self.create_lambda_vals(Q)
        #z = self.mult_precond_approximate_eigenmodes(r,Q,lambda_)
        z = mult_precond(r)        
        p = z.copy()
        rz = np.dot(r,z)
        rz_k = rz;
        for it in range(max_it):
            ax = np.matmul(self.A, p)
            alpha = rz_k/np.dot(p,ax)
            x = x + p*alpha
            r = r - ax*alpha
            #z = self.mult_precond_approximate_eigenmodes(r,Q,lambda_)
            z = mult_precond(r)        
            rz = np.dot(r,z)
            res = np.linalg.norm(np.matmul(self.A, x)-b)
            res_arr = res_arr + [res]
            if res < tol:
                if verbose:
                    print("PCG residual = "+str(res))
                    print("PCG converged in "+str(it)+ " iterations.")
                return [x, res_arr]
            beta = rz/rz_k
            pk_1 = p.copy()
            p = z.copy()
            p = p + pk_1*beta
            rz_k = rz
        
        if verbose:
            print("PCG residual = "+str(res))
            print("PCG converged in "+str(max_it)+ " iterations.")
            
        return [x, res_arr]
    
    
    def cg_normal(self,x,b,max_it=100,tol=1.0e-12,verbose=False):
        res = np.linalg.norm(self.multiply_A(x)-b)
        res_arr = [res]
        if verbose:
            print("first cg residual is "+str(res))
        if res < tol:
            if verbose:
                print("CG converged in 0 iterations")
            return [x, res_arr]
        ax = self.multiply_A(x)
        r = b.copy()
        r = r - ax
        p = r.copy()
        rr_k = np.dot(r,r)
        for it in range(max_it):
            ax = self.multiply_A(p)
            alpha = rr_k/np.dot(p,ax)
            x = x+alpha*p
            res = np.linalg.norm(self.multiply_A(x)-b)
            res_arr = res_arr + [res]
            if res < tol:
                if verbose:
                    print("CG residual = "+str(res))
                    print("CG converged in "+str(it)+" iteration.")
                return [x, res_arr]
            r = r - ax*alpha
            rr_k1 = np.dot(r,r)
            beta = rr_k1/rr_k
            q = p.copy()
            p = r.copy()
            p = p+ q*beta
            rr_k = rr_k1
        
        if verbose:
            print("CG residual = " + str(res))
            print("CG used max = "+str(max_it)+" iteration")  
        
        return [x, res_arr]
    
    def lanczos_pcg(self, x_init, b, mult_precond, max_it=100, tol=1.0e-12,verbose=True):
        x_sol = x_init.copy()
        r = b.copy() - self.multiply_A(x_init)
        
        q_bar0 = np.zeros(b.shape) #q_-1
        q_bar1 = mult_precond(r)   #q_0
        t1 = np.sqrt(np.dot(r,q_bar1))
        q_bar1 = q_bar1/t1
        
        Aq_bar1 = self.multiply_A(q_bar1)
        beta1 = 0 #beta0 = 0
        alpha1 = np.dot(q_bar1,Aq_bar1) 
        d1 = alpha1 #d0 = alpha0
        p_bar1 = q_bar1/d1
        x_sol = x_sol + t1*p_bar1
        
        for i in range(1, max_it):
            q_bar2 = mult_precond(Aq_bar1) # q_bar2 = MAq_bar1
            beta2 = np.sqrt(np.dot(q_bar2,Aq_bar1) - alpha1**2-beta1**2) #beta1 
            q_bar2 = (q_bar2 - alpha1*q_bar1 - beta1*q_bar0)/beta2
            Aq_bar2 = self.multiply_A(q_bar2)
            alpha2 = np.dot(Aq_bar2, q_bar2) #alpha1
            mu = beta2/d1
            d2 = alpha2 - d1*mu**2
            
            
            alpha1 = alpha2
            beta1 = beta2
            d1 = d2
            q_bar0 = q_bar1.copy()
            q_bar1 = q_bar2.copy()
            Aq_bar1 = Aq_bar2.copy()
        
        return x_sol
    
    
    
    def lanczos_pcg_old(self, x_init, b, mult_precond, max_it=100, tol=1.0e-12,verbose=True):
        x_sol = x_init.copy()
        r = b.copy() - self.multiply_A(x_init)
        r_norm = np.linalg.norm(b - self.multiply_A(x_init))
        res_arr = [r_norm]
        if r_norm<tol:
            if verbose:
                print("Converged without PCG iteration. residual = "+str(r_norm))
            return x_sol, res_arr
        q_bar_old = np.zeros(b.shape)
        w_tilde = r.copy()
        w_bar = mult_precond(w_tilde)
        mag = np.sqrt(np.dot(w_bar,w_tilde))
        q_bar = w_bar/mag
        w_tilde = self.multiply_A(q_bar)
        alpha = np.dot(q_bar,w_tilde)
        beta = 0
        d = alpha
        t = mag
        p_bar = q_bar.copy()
        x_sol = x_sol + p_bar*t/d
        res = np.linalg.norm(b - self.multiply_A(x_sol))
        res_arr = res_arr + [res]
        if res < tol:
            print("Converged with one PCG iteration. final residual = "+str(res))
            return x_sol, res_arr
        
        for i in range(1,max_it):
            w_bar = mult_precond(w_tilde)
            beta_new_squared = np.dot(w_bar,w_tilde) -alpha**2 - beta**2
            if beta_new_squared < tol:
                print("PCG converged to beta < 0 in "+str(i) +" iterations. Final PCG residual = "+str(res))
                return x_sol, res_arr           
            w_bar = w_bar - q_bar*alpha - q_bar_old*beta
            q_bar_old = q_bar.copy()
            beta = np.sqrt(beta_new_squared)
            q_bar = w_bar.copy()/beta
            w_tilde = self.multiply_A(q_bar)
            alpha = np.dot(q_bar,w_tilde)
            mu = beta/d
            t = -mu*t
            d = alpha - d*mu**2
            p_bar = -p_bar*mu + q_bar
            x_sol = x_sol + p_bar*t/d
            res = np.linalg.norm(b - self.multiply_A(x_sol))
            res_arr = res_arr + [res]
            if res<tol:
                if verbose: 
                    print("PCG converged in "+str(i)+ " iterations. Final residual = "+str(res))
                return x_sol, res_arr
        if verbose: 
            print("PCG converged in max iteration ("+str(max_it)+ " iterations). Final residual = "+str(res))
        return x_sol, res_arr
        
    
    def lanczos_iteration(self, b, max_it=10, tol=1.0e-10):
        if max_it > self.n:
            max_it = self.n
        diagonal = np.zeros(max_it)
        sub_diagonal = np.zeros(max_it)
        Q = np.zeros([max_it, self.n])
        norm_b = np.linalg.norm(b)
        Q[0] = b.copy()/norm_b
        Q[1] = np.matmul(self.A, Q[0])
        diagonal[0] = np.dot(Q[1],Q[0])
        Q[1] = Q[1] - diagonal[0]*Q[0]
        sub_diagonal[0] = np.linalg.norm(Q[1])
        Q[1] = Q[1]/sub_diagonal[0]
        if sub_diagonal[0]<tol:
            Q = np.resize(Q,[1,self.n])
            diagonal = np.resize(diagonal, [1])
            sub_diagonal = np.resize(sub_diagonal, [0])
            return Q, diagonal, sub_diagonal
        
        invariant_subspace = False
        it = 1
        while ((it<max_it-1) and (not invariant_subspace)):
            Q[it+1] = np.matmul(self.A, Q[it])
            diagonal[it] = np.dot(Q[it],Q[it+1])
            Q[it+1] = Q[it+1] - diagonal[it]*Q[it]-sub_diagonal[it-1]*Q[it-1]
            sub_diagonal[it] = np.linalg.norm(Q[it+1])
            Q[it+1] = Q[it+1]/sub_diagonal[it]
            if sub_diagonal[it] < tol:
                invariant_subspace = True
            it = it+1
            
        Q = np.resize(Q, [it+1,self.n])
        diagonal = np.resize(diagonal, [it+1])
        sub_diagonal = np.resize(sub_diagonal, [it])
        if not invariant_subspace:
            diagonal[it] = np.dot(Q[it], np.matmul(self.A,Q[it]))
        
        return Q, diagonal, sub_diagonal
                
    #Update this part, maybe remove
    def restarted_pcg_automatic(self, b, max_outer_it = 100, pcg_inner_it = 1, tol = 1.0e-15, method = "approximate_eigenmodes", num_vectors = 16, verbose = False):
        res_arr = []
        x_sol = np.zeros(b.shape)
        b_iter = b.copy()
        x_init = np.zeros(b.shape)
        for i in range(max_outer_it):
            if method == "approximate_eigenmodes":
                Q = self.create_ritz_vectors(b_iter,num_vectors)
                lambda_ = self.create_ritz_values(Q)
                mult_precond = lambda x: self.mult_precond_method1(x,Q,lambda_)
            else:
                print("Method is not recognized!")
                return
            x_sol1, res_arr1 = self.pcg_normal(x_init, b_iter, mult_precond, pcg_inner_it, tol, False)
            x_sol = x_sol + x_sol1
            b_iter = b - np.matmul(self.A,x_sol)
            b_norm = np.linalg.norm(b_iter)
            res_arr = res_arr + res_arr1[0:pcg_inner_it]

            if verbose:
                print("restarting at i = "+ str(i)+ " , residual = "+ str(b_norm))            
            if b_norm < tol:
                print("RestartedPCG converged in "+str(i)+" iterations.")
                break
        return x_sol, res_arr


    def restarted_pcg_manual(self, b, mult_precond_method, max_outer_it = 100, pcg_inner_it = 1, tol = 1.0e-15, verbose = False):
        #mult_precond_method(CG,x, b)
        res_arr = []
        x_sol = np.zeros(b.shape)
        b_iter = b.copy()
        x_init = np.zeros(b.shape)
        for i in range(max_outer_it):
            mult_precond = lambda x: mult_precond_method(self, x, b_iter)
            x_sol1, res_arr1 = self.pcg_normal(x_init, b_iter, mult_precond, pcg_inner_it, tol, False)
            x_sol = x_sol + x_sol1
            b_iter = b - np.matmul(self.A,x_sol)
            b_norm = np.linalg.norm(b_iter)
            res_arr = res_arr + res_arr1[0:pcg_inner_it]
            if verbose:
                print("restarting at i = "+ str(i)+ " , residual = "+ str(b_norm))            
            if b_norm < tol:
                print("RestartedPCG converged in "+str(i)+" iterations.")
                break
        return x_sol, res_arr
    
    
    
    
